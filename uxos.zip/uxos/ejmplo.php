<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Inciso a)</h1>
    

    <?php

$cadena='aprender';
$cadena1='aprende';

echo '<p>'.str_pad($cadena,18,'*',STR_PAD_BOTH).'</p>';


echo '<p>'.str_pad($cadena1,17,'*',STR_PAD_BOTH).'</p>';



  ?>

  <br>
  <h1>Inciso b)</h1>
  
  <?php
  
$cadena='aprender';
$cadena1='aprende';
$subcadena=substr($cadena,0,3);
$subcadena1=substr($cadena1,0,3);

echo "La primera cadena es: ".$cadena.'</p>';
echo "La segunda cadena es: ".$cadena1.'</p>';
echo "La subcadena 1 cadena es: ".$subcadena.'</p>';
echo "La subcadena 2 cadena es: ".$subcadena1.'</p>';
echo 'Si comparamos las dos subcadenas con un if</p>';

  if (strcmp($subcadena1, $subcadena) == 0) {echo 'Según strcmp las dos subcadenas son iguales';}

else {echo 'Según strcmp las dos cadenas NO son iguales'; }

?>

</body>
</html>