<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>DaiBank</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.1.3/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,700|Raleway:400,700&display=swap" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
          <a class="navbar-brand" href="index.html">
            <span>
              DaiBank
            </span>
          </a>

          <div class="navbar-collapse" id="">
            <div class="custom_menu-btn">
              <button onclick="openNav()">
                <span class="s-1"> </span>
                <span class="s-2"> </span>
                <span class="s-3"> </span>
              </button>
            </div>
            <div id="myNav" class="overlay">
              <div class="overlay-content">
                <a href="index.html">HOME</a>
                <a href="about.html">ABOUT</a>
                <a href="feature.html">FEATURE</a>
                <a href="contact.html">CONTACT US</a>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
  </div>


  <!-- about section -->
  <section class="about_section layout_padding">
    <div class="container">
      <div class="heading_container d-flex justify-content-lg-start">
        <h2>
          About Us
        </h2>
      </div>
      <div class="layout_padding2-top">
        <div class="row">
          <div class="col-md-5">
            <div class="detail-box b-1">
              <p>
                Aqui podras conocer como funciona nuestro sistema de prestamos
                con un ejemplo de una tabla de amortizacion
              </p>
            </div>
            
            
          </div>
          <div class="col-md-5">
            <div class="detail-box b-2">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <h1 align="center">Tabla de amortizacion</h1>
  <p align="center">Prestamo de $10000.
  Interes de 3%.
  Plazo de 12 meses.</p>
 <?php
  $i = 3;
  $p = 10000;
  $m = 12;
  $vi = ($i*100)/$p;
  
  $pago=$p*(($vi/$m)/(1-pow(1+($vi/$m),(-$m))));
  echo "<br><b>----Pago por mes sera de: $</b>".$pago;
  
  $int = $vi/$m;
  echo "</p>";
  #pago1
  $intereses = $p * $int;
  $amort = $pago - $intereses;
  $nuevo_saldo = $p - $amort;

  #pago2
  $intereses2 = $nuevo_saldo * $int;
  $amort2 = $pago - $intereses2;
  $nuevo_saldo2 = $nuevo_saldo - $amort2;

  #pago3
  $intereses3 = $nuevo_saldo2 * $int;
  $amort3 = $pago - $intereses3;
  $nuevo_saldo3 = $nuevo_saldo2 - $amort3;

  #pago4
  $intereses4 = $nuevo_saldo3 * $int;
  $amort4 = $pago - $intereses4;
  $nuevo_saldo4 = $nuevo_saldo3 - $amort4;

  #pago5
  $intereses5 = $nuevo_saldo4 * $int;
  $amort5 = $pago - $intereses5;
  $nuevo_saldo5 = $nuevo_saldo4 - $amort5;

  #pago6
  $intereses6 = $nuevo_saldo5 * $int;
  $amort6 = $pago - $intereses6;
  $nuevo_saldo6 = $nuevo_saldo5 - $amort6;

  #pago7
  $intereses7 = $nuevo_saldo6 * $int;
  $amort7 = $pago - $intereses7;
  $nuevo_saldo7 = $nuevo_saldo6 - $amort7;

  #pago8
  $intereses8 = $nuevo_saldo7 * $int;
  $amort8 = $pago - $intereses8;
  $nuevo_saldo8 = $nuevo_saldo7 - $amort8;

  #pago9
  $intereses9 = $nuevo_saldo8 * $int;
  $amort9 = $pago - $intereses9;
  $nuevo_saldo9 = $nuevo_saldo8 - $amort9;

  #pago10
  $intereses10 = $nuevo_saldo9 * $int;
  $amort10 = $pago - $intereses10;
  $nuevo_saldo10 = $nuevo_saldo9 - $amort10;

  #pago11
  $intereses11 = $nuevo_saldo10 * $int;
  $amort11 = $pago - $intereses11;
  $nuevo_saldo11 = $nuevo_saldo10 - $amort11;

  #pago12
  $intereses12 = $nuevo_saldo11 * $int;
  $amort12 = $pago - $intereses12;
  $nuevo_saldo12 = $nuevo_saldo11 - $amort12;


  ?>

  <table align="center" border="1">
    <th align="center" bgcolor="purple">Plazo de mes</th>
    <th align="center" bgcolor="purple">Pago realizado</th>
    <th align="center" bgcolor="purple">Intereses</th>
    <th align="center" bgcolor="purple">Amortizacion</th>
    <th align="center" bgcolor="purple">Saldo</th>
    <tr>
    <td align="center">0</td><td align="center">-</td><td align="center">-</td>
    <td align="center">-</td><td align="center">10000</td>
    </tr>
    <td align="center">1</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses ?></td>
    <td align="center"><?php echo $amort ?></td>
    <td align="center"><?php echo $nuevo_saldo ?></td>
    </tr>
    <td align="center">2</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses2 ?></td>
    <td align="center"><?php echo $amort2 ?></td>
    <td align="center"><?php echo $nuevo_saldo2 ?></td>
    </tr>
    </tr>
    <td align="center">3</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses3 ?></td>
    <td align="center"><?php echo $amort3 ?></td>
    <td align="center"><?php echo $nuevo_saldo3 ?></td>
    </tr>
    </tr>
    <td align="center">4</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses4 ?></td>
    <td align="center"><?php echo $amort4 ?></td>
    <td align="center"><?php echo $nuevo_saldo4 ?></td>
    </tr>
    </tr>
    <td align="center">5</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses5 ?></td>
    <td align="center"><?php echo $amort5 ?></td>
    <td align="center"><?php echo $nuevo_saldo5 ?></td>
    </tr>
    </tr>
    <td align="center">6</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses6 ?></td>
    <td align="center"><?php echo $amort6 ?></td>
    <td align="center"><?php echo $nuevo_saldo6 ?></td>
    </tr>
    </tr>
    <td align="center">7</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses7 ?></td>
    <td align="center"><?php echo $amort7 ?></td>
    <td align="center"><?php echo $nuevo_saldo7 ?></td>
    </tr>
    </tr>
    <td align="center">8</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses8 ?></td>
    <td align="center"><?php echo $amort8 ?></td>
    <td align="center"><?php echo $nuevo_saldo8 ?></td>
    </tr>
    </tr>
    <td align="center">9</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses9 ?></td>
    <td align="center"><?php echo $amort9 ?></td>
    <td align="center"><?php echo $nuevo_saldo9 ?></td>
    </tr>
    </tr>
    <td align="center">10</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses10 ?></td>
    <td align="center"><?php echo $amort10 ?></td>
    <td align="center"><?php echo $nuevo_saldo10 ?></td>
    </tr>
    </tr>
    <td align="center">11</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses11 ?></td>
    <td align="center"><?php echo $amort11 ?></td>
    <td align="center"><?php echo $nuevo_saldo11 ?></td>
    </tr>
    </tr>
    <td align="center">12</td><td align="center"><?php echo $pago ?></td>
    <td align="center"><?php echo $intereses12 ?></td>
    <td align="center"><?php echo $amort12 ?></td>
    <td align="center">0.00</td>
    </tr>
    

  </table>
  
  

  <!-- end about section -->


  <!-- info section -->
  <section class="info_section layout_padding-top">
    <div class="info_logo-box">
      <h2>
        DaiBank
      </h2>
    </div>
    <div class="container layout_padding2">
      <div class="row">
        <div class="col-md-3">
          <h5>
            About Us
          </h5>
          <p>
            Somos tu banco de confianza sin papeleos absurdos que busca dar un credito 
            a los ciudadanos de nuestro pais y mas.
          </p>
        </div>
        <div class="col-md-3">
          <h5>
            Useful Link
          </h5>
          <ul>
            <li>
              <a href="">
                Video games
              </a>
            </li>
            <li>
              <a href="">
                Remote control
              </a>
            </li>
            <li>
              <a href="">
                3d controller
              </a>
            </li>
          </ul>
        </div>
        <div class="col-md-3">
          <h5>
            Contact Us
          </h5>
          <p>
            dolor sit amet, consectetur magna aliqua. quisdotempor incididunt ut e
          </p>
        </div>
        <div class="col-md-3">

          <div class="subscribe_container">
            <h5>
              Newsletter
            </h5>
            <div class="form_container">
              <form action="">
                <input type="email" placeholder="Enter your email">
                <button type="submit">
                  Subscribe
                </button>
              </form>
            </div>
          </div>

        </div>
      </div>
    </div>
    <div class="container">
      <div class="social_container">

        <div class="social-box">
          <a href="">
            <img src="images/fb.png" alt="">
          </a>

          <a href="">
            <img src="images/twitter.png" alt="">
          </a>
          <a href="">
            <img src="images/linkedin.png" alt="">
          </a>
          <a href="">
            <img src="images/instagram.png" alt="">
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->
  <!-- footer section -->
  <section class="container-fluid footer_section">
    <p>
      &copy; 2019 All Rights Reserved. Design by
      <a href="https://html.design/">Free Html Templates</a>
    </p>
  </section>
  <!-- footer section -->

  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>

  <script>
    function openNav() {
      document.getElementById("myNav").classList.toggle("menu_width");
      document
        .querySelector(".custom_menu-btn")
        .classList.toggle("menu_btn-style");
    }
  </script>
</body>

</html>